#include <stdio.h>

int main(){
   printf("the program is running\n");
   return 0;
}
